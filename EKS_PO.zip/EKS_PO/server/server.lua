Config = Config or {}

RegisterNetEvent("eks_flamekit:debugServer")
AddEventHandler("eks_flamekit:debugServer", function(msg)
    if Config.Debug then
        print("[EKS FlameKit] " .. tostring(msg))
    end
end)

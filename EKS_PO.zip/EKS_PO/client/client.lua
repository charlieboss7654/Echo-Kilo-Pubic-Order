local currentKit = nil
local kitIntegrity = 0.0
local barVisible = false
local movingBar = false
local extinguishInProgress = false
local promptVisible = false
local lastHealth = nil
local timeOnFire = 0.0

local function debug(msg)
    if Config.Debug then
        print("^3[EKS FlameKit]^7 " .. tostring(msg))
    end
end

local function isMpPed(ped)
    local m = GetEntityModel(ped)
    return m == `mp_m_freemode_01` or m == `mp_f_freemode_01`
end

local function isMale(ped)
    return GetEntityModel(ped) == `mp_m_freemode_01`
end

local function applyUniform(kit)
    local ped = PlayerPedId()
    if not isMpPed(ped) then return false end

    local cfg = isMale(ped) and kit.male or kit.female

    for comp, data in pairs(cfg.components) do
        SetPedComponentVariation(ped, comp, data.drawable, data.texture, 0)
    end

    for prop, data in pairs(cfg.props) do
        ClearPedProp(ped, prop)
        if data.drawable >= 0 then
            SetPedPropIndex(ped, prop, data.drawable, data.texture, true)
        end
    end

    return true
end

local function wearingAnyTrigger(kit)
    local ped = PlayerPedId()
    if not isMpPed(ped) then return false end

    local triggers = kit.triggers.components
    local cfg = isMale(ped) and kit.male or kit.female

    for _, compId in ipairs(triggers) do
        local t = cfg.components[compId]
        if t then
            if GetPedDrawableVariation(ped, compId) == t.drawable and
               GetPedTextureVariation(ped, compId) == t.texture then
                return true
            end
        end
    end
    return false
end

local function showBar()
    barVisible = true

    local x = GetResourceKvpFloat("eks_flamekit_bar_x")
    local y = GetResourceKvpFloat("eks_flamekit_bar_y")

    if x == 0.0 then x = Config.BarPosition.x end
    if y == 0.0 then y = Config.BarPosition.y end

    SendNuiMessage(json.encode({
        action = "showBar",
        integrity = kitIntegrity,
        x = x,
        y = y
    }))
end

local function hideBar()
    barVisible = false
    SendNuiMessage(json.encode({ action = "hideBar" }))
end

local function updateBar()
    if not barVisible then return end

    SendNuiMessage(json.encode({
        action = "updateBar",
        integrity = kitIntegrity
    }))
end

local function showPrompt()
    if promptVisible then return end
    promptVisible = true
    SendNuiMessage(json.encode({ action = "showPrompt" }))
end

local function hidePrompt()
    if not promptVisible then return end
    promptVisible = false
    SendNuiMessage(json.encode({ action = "hidePrompt" }))
end

local function hasKit()
    return currentKit ~= nil and kitIntegrity > 0.0
end

local function activateKit(kit)
    currentKit = kit.id
    kitIntegrity = Config.UniformSettings.MaxIntegrity
    showBar()
    updateBar()
end

local function removeKit()
    currentKit = nil
    kitIntegrity = 0.0
    hideBar()
    hidePrompt()
end

CreateThread(function()
    while true do
        local ped = PlayerPedId()

        local found = nil
        for _, kit in ipairs(Config.Uniforms) do
            if wearingAnyTrigger(kit) then
                found = kit
                break
            end
        end

        if found and not currentKit then
            activateKit(found)
        elseif not found and currentKit then
            removeKit()
        end

        Wait(1000)
    end
end)

CreateThread(function()
    while true do
        local ped = PlayerPedId()
        local dt = GetFrameTime()

        if hasKit() then
            if IsEntityOnFire(ped) then
                showPrompt()

                kitIntegrity = kitIntegrity - (Config.UniformSettings.FireDrainPerSecond * dt)
                if kitIntegrity < 0.0 then kitIntegrity = 0.0 end
                updateBar()

                if kitIntegrity <= 0.0 then
                    hidePrompt()
                end
            else
                hidePrompt()
                timeOnFire = 0.0
            end
        else
            hidePrompt()
        end

        Wait(0)
    end
end)

CreateThread(function()
    while true do
        local ped = PlayerPedId()
        local hp = GetEntityHealth(ped)

        if lastHealth == nil then
            lastHealth = hp
        else
            if hasKit() then
                if hp < lastHealth then
                    local damage = lastHealth - hp

                    if IsEntityOnFire(ped) then
                        SetEntityHealth(ped, lastHealth)
                        hp = lastHealth
                    else
                        lastHealth = hp
                    end
                else
                    lastHealth = hp
                end
            else
                lastHealth = hp
            end
        end

        Wait(10)
    end
end)

RegisterCommand(Config.Keybinds.ExtinguishCommand, function()
    local ped = PlayerPedId()
    if not hasKit() then return end
    if not IsEntityOnFire(ped) then return end
    if extinguishInProgress then return end

    extinguishInProgress = true
    hidePrompt()

    TaskStartScenarioInPlace(ped, "WORLD_HUMAN_JOG_STANDING", 0, true)
    Wait(5000)

    StopEntityFire(ped)
    ClearPedTasksImmediately(ped)

    extinguishInProgress = false
    timeOnFire = 0.0
end)

RegisterKeyMapping(
    Config.Keybinds.ExtinguishCommand,
    "Extinguish Flames",
    "keyboard",
    Config.Keybinds.ExtinguishDefault
)

CreateThread(function()
    if not exports or not exports.ox_target then
        debug("ox_target not found; third-eye disabled.")
        return
    end

    exports.ox_target:addGlobalVehicle({
        {
            name = "eks_flamekit_uniform",
            icon = "fa-solid fa-shirt",
            label = "Acquire Uniform",

            canInteract = function(entity, distance, coords, name)
                if distance > 3.0 then return false end
                if not Config.KitVehicles or #Config.KitVehicles == 0 then
                    return true
                end

                local model = GetEntityModel(entity)
                for _, hash in ipairs(Config.KitVehicles) do
                    if model == hash then
                        return true
                    end
                end
                return false
            end,

            onSelect = function(data)
                local uniforms = {}
                for _, kit in ipairs(Config.Uniforms) do
                    uniforms[#uniforms+1] = { id = kit.id, label = kit.label }
                end

                SetNuiFocus(true, true)
                SendNuiMessage(json.encode({
                    action = "openUniformMenu",
                    uniforms = uniforms
                }))
            end
        }
    })
end)

RegisterNUICallback("selectUniform", function(data, cb)
    if data and data.id then
        for _, kit in ipairs(Config.Uniforms) do
            if kit.id == data.id then
                applyUniform(kit)
                activateKit(kit)
                break
            end
        end
    end

    SendNuiMessage(json.encode({ action = "closeUniformMenu" }))
    SetNuiFocus(false, false)
    cb("ok")
end)

RegisterNUICallback("closeMenu", function(_, cb)
    SendNuiMessage(json.encode({ action = "closeUniformMenu" }))
    SetNuiFocus(false, false)
    cb("ok")
end)

RegisterCommand(Config.MoveBarCommand, function()
    if not hasKit() then
        BeginTextCommandThefeedPost("STRING")
        AddTextComponentSubstringPlayerName("~r~You must be wearing a Flame Kit to move the bar.")
        EndTextCommandThefeedPostTicker(false, false)
        return
    end

    movingBar = true
    SetNuiFocus(true, true)
    SendNuiMessage(json.encode({ action = "moveMode" }))
end)

RegisterNUICallback("savePosition", function(data, cb)
    if data and data.x and data.y then
        SetResourceKvpFloat("eks_flamekit_bar_x", data.x)
        SetResourceKvpFloat("eks_flamekit_bar_y", data.y)
    end
    movingBar = false
    SetNuiFocus(false, false)
    cb("ok")
end)

RegisterNUICallback("cancelMove", function(_, cb)
    movingBar = false
    SetNuiFocus(false, false)
    cb("ok")
end)

CreateThread(function()
    Wait(1000)
    SendNuiMessage(json.encode({
        action = "setKey",
        key = Config.Keybinds.ExtinguishDefault
    }))
end)

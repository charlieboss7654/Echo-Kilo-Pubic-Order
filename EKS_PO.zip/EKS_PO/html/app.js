let bar = null;
let barFill = null;
let barPercent = null;
let prompt = null;
let keyText = null;

let uniformModal = null;
let uniformList = null;
let uniformClose = null;

let moveOverlay = null;

let dragging = false;
let offsetX = 0;
let offsetY = 0;
let pos = { x: 0.87, y: 0.78 };

window.addEventListener("DOMContentLoaded", () => {
    bar = document.getElementById("kit-bar");
    barFill = document.getElementById("kit-bar-fill");
    barPercent = document.getElementById("kit-bar-percent");

    prompt = document.getElementById("extinguish-prompt");
    keyText = document.getElementById("extinguish-text");

    uniformModal = document.getElementById("uniform-modal");
    uniformList = document.getElementById("uniform-list");
    uniformClose = document.getElementById("uniform-close");

    moveOverlay = document.getElementById("move-overlay");

    if (uniformClose) {
        uniformClose.onclick = () => {
            fetchNui("closeMenu");
        };
    }

    if (bar) {
        bar.addEventListener("mousedown", (e) => {
            if (!moveOverlay || moveOverlay.classList.contains("hidden")) return;
            dragging = true;
            offsetX = e.clientX - bar.offsetLeft;
            offsetY = e.clientY - bar.offsetTop;
        });
    }

    document.addEventListener("mousemove", (e) => {
        if (!dragging || !bar) return;

        bar.style.left = (e.clientX - offsetX) + "px";
        bar.style.top = (e.clientY - offsetY) + "px";

        pos.x = bar.offsetLeft / window.innerWidth;
        pos.y = bar.offsetTop / window.innerHeight;
    });

    document.addEventListener("mouseup", () => {
        if (dragging) {
            dragging = false;
            if (moveOverlay && !moveOverlay.classList.contains("hidden")) {
                fetchNui("savePosition", pos);
                moveOverlay.classList.add("hidden");
            }
        }
    });

    document.addEventListener("keydown", (e) => {
        if (e.key === "Escape" && moveOverlay && !moveOverlay.classList.contains("hidden")) {
            moveOverlay.classList.add("hidden");
            fetchNui("cancelMove");
        }
    });
});

window.addEventListener("message", (ev) => {
    const data = ev.data;

    switch (data.action) {
        case "showBar":
            if (bar) {
                bar.classList.remove("hidden");
                bar.style.left = (data.x * window.innerWidth) + "px";
                bar.style.top = (data.y * window.innerHeight) + "px";
                updateBar(data.integrity);
            }
            break;

        case "hideBar":
            if (bar) bar.classList.add("hidden");
            break;

        case "updateBar":
            updateBar(data.integrity);
            break;

        case "showPrompt":
            if (prompt) prompt.classList.remove("hidden");
            break;

        case "hidePrompt":
            if (prompt) prompt.classList.add("hidden");
            break;

        case "setKey":
            if (keyText) {
                keyText.textContent = `Press [${data.key}] to put out fire`;
            }
            break;

        case "openUniformMenu":
            if (!uniformModal || !uniformList) return;
            uniformList.innerHTML = "";
            (data.uniforms || []).forEach(u => {
                const item = document.createElement("div");
                item.className = "eks-uniform-item";
                item.textContent = u.label;
                item.onclick = () => {
                    fetchNui("selectUniform", { id: u.id });
                };
                uniformList.appendChild(item);
            });
            uniformModal.classList.remove("hidden");
            break;

        case "closeUniformMenu":
            if (uniformModal) uniformModal.classList.add("hidden");
            break;

        case "moveMode":
            if (moveOverlay) moveOverlay.classList.remove("hidden");
            break;
    }
});

function updateBar(val) {
    if (!barFill || !barPercent) return;
    val = Math.max(0, Math.min(100, val));
    barFill.style.width = val + "%";
    barPercent.textContent = Math.round(val) + "%";
}

function fetchNui(event, data = {}) {
    fetch(`https://${GetParentResourceName()}/${event}`, {
        method: "POST",
        body: JSON.stringify(data)
    });
}

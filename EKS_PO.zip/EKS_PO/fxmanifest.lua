fx_version 'cerulean'
game 'gta5'

lua54 'yes'

name 'EKS_FlameKit'
author 'EKS Scripts'
description 'Flame Retardant Kit System'
version '1.0.0'

ui_page 'html/index.html'

files {
    'html/index.html',
    'html/style.css',
    'html/app.js'
}

client_scripts {
    'shared/config.lua',
    'client/client.lua'
}

server_scripts {
    'shared/config.lua',
    'server/server.lua'
}

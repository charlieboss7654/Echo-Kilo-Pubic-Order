Config = {}

Config.Debug = false

Config.UniformSettings = {
    MaxIntegrity = 100.0,
    FireDrainPerSecond = 8.0,
    AutoExtinguishTime = 6.0,
    AutoExtinguishSprintMultiplier = 1.8,
    BulletMaxDamagePerHit = 5,
    OtherMaxDamagePerHit = 1
}

Config.KitVehicles = {
    `firetruk`,
    `riot`,
    `ambulance`
}

-- Players configure FULL UNIFORMS here
-- Protection needs only ONE "trigger component" to match (shirt OR pants)
Config.Uniforms = {
    {
        id = "lfb_kit",
        label = "LFB Flame Retardant Kit",

        triggers = { -- One matching component is enough
            components = { 11, 4 },  -- Shirt = 11, Pants = 4 (example)
        },

        male = {
            components = {
                [3]  = { drawable = 12, texture = 0 },
                [4]  = { drawable = 25, texture = 0 },
                [6]  = { drawable = 10, texture = 0 },
                [8]  = { drawable = 15, texture = 0 },
                [11] = { drawable = 52, texture = 0 }
            },

            props = {
                -- example: [0] = { drawable = 5, texture = 0 }
            }
        },

        female = {
            components = {
                [3]  = { drawable = 14, texture = 0 },
                [4]  = { drawable = 30, texture = 0 },
                [6]  = { drawable = 14, texture = 0 },
                [8]  = { drawable = 7, texture = 0 },
                [11] = { drawable = 44, texture = 0 }
            },

            props = {}
        }
    }
}

Config.Keybinds = {
    ExtinguishCommand = "eks_extinguish",
    ExtinguishDefault = "E"
}

Config.MoveBarCommand = "movekitbar"

Config.BarPosition = {
    x = 0.87,
    y = 0.78
}